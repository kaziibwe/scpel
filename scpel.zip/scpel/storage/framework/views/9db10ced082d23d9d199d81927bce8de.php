

helo
<?php /**PATH /home/kaziibwe/Desktop/phrunsys/scpel/resources/views/welcome.blade.php ENDPATH**/ ?>